/*******************************************
 * Grupo: Luiz Gustavo Bragança dos Santos *
 *        Maria Clara Dias                 *
 *        Pedro Augusto Prosdocimi         *
 *******************************************/

Como Compilar:

    - Sequencial: $ gcc kmeans.cpp -o kmeans
    - Paralelo:   $ gcc kmeans.cpp -o kmeans -fopenmp

Como Rodar o Código:

    time ./kmeans < datasets/pub.in
    
________________________________________________________________________________
Link do Código Sequencial: https://github.com/marcoscastro/kmeans